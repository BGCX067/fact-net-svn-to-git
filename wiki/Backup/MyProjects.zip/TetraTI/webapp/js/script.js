/**
 * Scripts gerais do sistema.
 */

function defineMargin(objetos){
	var itensTrabalhados = $(objetos);
	var tamanhoUtil = $($(".content")[1]).width();
	var quantidadeGrids = itensTrabalhados.length;
	
	var marginSize = ((tamanhoUtil/quantidadeGrids) - $(".novidades").innerWidth())/2;
	itensTrabalhados.css("margin", "0 "+marginSize+"px");
	itensTrabalhados.first().css({"margin-right":marginSize+"px","margin-left":0+"px"});
	itensTrabalhados.last().css({"margin-left":marginSize+"px","margin-right":0+"px"});
	
}